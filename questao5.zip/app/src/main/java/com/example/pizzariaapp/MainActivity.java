package com.example.pizzariaapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    CheckBox calabresa, marguerita, portuguesa;
    Button btnNext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        calabresa = findViewById(R.id.cbCalabresa);
        marguerita = findViewById(R.id.cbMarguerita);
        portuguesa = findViewById(R.id.cbPortuguesa);
        btnNext = findViewById(R.id.btnNext);

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ArrayList<String> pizzas = new ArrayList<>();
                if (calabresa.isChecked()) pizzas.add("Calabresa");
                if (marguerita.isChecked()) pizzas.add("Marguerita");
                if (portuguesa.isChecked()) pizzas.add("Portuguesa");

                if (pizzas.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Selecione ao menos uma pizza!", Toast.LENGTH_SHORT).show();
                } else {
                    Intent i = new Intent(MainActivity.this, SecondActivity.class);
                    i.putExtra("pizzas", pizzas);
                    startActivity(i);
                }
            }
        });
    }
}
