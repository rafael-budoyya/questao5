package com.example.pizzariaapp;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class SummaryActivity extends AppCompatActivity {

    TextView tvResumo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary);

        tvResumo = findViewById(R.id.tvResumo);

        ArrayList<String> pizzas = getIntent().getStringArrayListExtra("pizzas");
        String tamanho = getIntent().getStringExtra("tamanho");
        String pagamento = getIntent().getStringExtra("pagamento");
        double valor = getIntent().getDoubleExtra("valor", 0);

        StringBuilder resumo = new StringBuilder();
        resumo.append("Pizzas escolhidas:
");
        for (String p : pizzas) resumo.append("- ").append(p).append("\n");
        resumo.append("Tamanho: ").append(tamanho).append("\n");
        resumo.append("Pagamento: ").append(pagamento).append("\n");
        resumo.append("Valor Total: R$ ").append(String.format("%.2f", valor));

        tvResumo.setText(resumo.toString());
    }
}
