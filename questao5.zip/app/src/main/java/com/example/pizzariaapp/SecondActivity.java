package com.example.pizzariaapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class SecondActivity extends AppCompatActivity {

    RadioGroup rgTamanho, rgPagamento;
    Button btnResumo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        rgTamanho = findViewById(R.id.rgTamanho);
        rgPagamento = findViewById(R.id.rgPagamento);
        btnResumo = findViewById(R.id.btnResumo);

        ArrayList<String> pizzas = getIntent().getStringArrayListExtra("pizzas");

        btnResumo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedTamanhoId = rgTamanho.getCheckedRadioButtonId();
                int selectedPagamentoId = rgPagamento.getCheckedRadioButtonId();

                if (selectedTamanhoId == -1 || selectedPagamentoId == -1) return;

                RadioButton rbTamanho = findViewById(selectedTamanhoId);
                RadioButton rbPagamento = findViewById(selectedPagamentoId);

                String tamanho = rbTamanho.getText().toString();
                String pagamento = rbPagamento.getText().toString();

                double valor = 0;
                switch (tamanho) {
                    case "Pequena": valor = 20.0; break;
                    case "Média": valor = 30.0; break;
                    case "Grande": valor = 40.0; break;
                }

                Intent i = new Intent(SecondActivity.this, SummaryActivity.class);
                i.putExtra("pizzas", pizzas);
                i.putExtra("tamanho", tamanho);
                i.putExtra("pagamento", pagamento);
                i.putExtra("valor", valor);
                startActivity(i);
            }
        });
    }
}
